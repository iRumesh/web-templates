export default [
  {
    src: "/img/gallery/1.jpg",
    alt: "Start Gallery",
    caption: "Start Gallery",
    width: 532,
    height: 500
  },
  {
    src:
      "/img/gallery/2.jpg",
    alt: "Variations of passages",
    caption: "Main Gallery",
    width: 532,
    height: 709
  },
  {
    src:
      "/img/gallery/3.jpg",
    alt: "Variations of passages",
    caption: "Dark Mode Gallery",
    width: 532,
    height: 517
  },
  {
    src:
      "/img/gallery/4.jpg",
    alt: "Variations of passages",
    caption: "Gallery Show",
    width: 532,
    height: 725
  },
  {
    src: "/img/gallery/5.jpg",
    alt: "Variations of passages",
    caption: "Variations Gallery",
    width: 532,
    height: 619
  },
  {
    src:
      "/img/gallery/6.jpg",
    alt: "Variations of passages",
    caption: "Gallery Mode",
    width: 532,
    height: 596
  },
  {
    src:
      "/img/gallery/1.jpg",
    alt: "Variations of passages",
    caption: "Variations Mode",
    width: 532,
    height: 709
  },
  {
    src:
      "/img/gallery/2.jpg",
    alt: "Variations of passages",
    caption: "Big Gallery",
    width: 532,
    height: 709
  },
  {
    src:
      "/img/gallery/5.jpg",
    alt: "Variations of passages",
    caption: "Show Gallery",
    width: 532,
    height: 619
  }
];
